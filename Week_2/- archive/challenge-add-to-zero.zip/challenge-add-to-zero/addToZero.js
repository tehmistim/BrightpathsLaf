// Starting array
let array = [28, 43, -12, 30, 4, 0, 12]

// Write your solution below: