// Starting array
let array = [28, 43, -12, 30, 4, 0, -36]

// Write your solution below: